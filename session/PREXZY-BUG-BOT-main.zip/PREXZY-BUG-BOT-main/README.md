<h1 align="center"> PREXZY BUG BOT </h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING ;PREXZY-BUG-BOT;WHATSAPP+BUG+BOT;CREATED+BY+PRECIOUS+AYOMIDE;RELEASED+05.08.24" alt="Typing SVG" /></a>
  </p>

  <p align="center">  
  <a href="https://whatsapp.com/channel/0029VaaUfPO8qIzztuf42D04">
    <img alt="wasi" height="300" src="https://telegra.ph/file/3a21bf26bedef7966fd74.jpg">
    <h1 align="center">PREXZY-BUG-BOT</h1>
  </a>
</p>
<p align="center">
<a href="https://github.com/Prexzybooster"><img title="Author" src="https://img.shields.io/badge/Prexzybooster-black?style=for-the-badge&logo=Github"></a> <a href="https://whatsapp.com/channel/0029VaaUfPO8qIzztuf42D04"><img title="Author" src="https://img.shields.io/badge/CHANNEL-black?style=for-the-badge&logo=whatsapp"></a> <a href="https://wa.me/+255616030473"><img title="Author" src="https://img.shields.io/badge/CHAT US-black?style=for-the-badge&logo=whatsapp"></a>

   
   

PREXZY BUG BOT is a bug bot designed to enhance the functionality and preferences of a user's whatsApp. As well as put an end to the era of scammers. Use reasonably

If you clone my repo or use as base bot, dont forget to give credits. PREXZYVILLA
### 1. FORK THIS REPO

<a href='https://github.com/Prexzybooster/PREXZY-BUG-BOT/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>
   


 **2.DEPLOYMENT PROCESS**
### DEPLOY ON PANEL
IF YOU DON'T HAVE A PANEL ACCOUNT CREATE ONE AND SERVER TO DEPLOY 
    <br>
    <a href='https://bot-hosting.net/?aff=1264676029318955030' target="_blank"><img alt='Panel' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=panel&logoColor=white'/></a>

### OR
### 1. <a href="https://prexzyvillasession.onrender.com/"><img src="https://img.shields.io/badge/PAIR_CODE-green" alt="Clique ici pour avoir le Pair-Code" width="90"></a>

## 2. <a href='https://dashboard.render.com/web/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-Deploy on render-black?style=for-the-badge&logo=render&logoColor=white'/>
## Watch Tutorial videos.
* [![YOUTUBE](https://img.shields.io/badge/HOW_TO_DEPLOY-red?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@prexzyvilla)

### DEPLOYMENT ON TERMUX

**Go to your termux and input this commands**





cd PREXZY-BUG-BOT

yarn install
   
npm start


If you see any question while upgrading with this options with Y for yes or N for no = Click yes or y

If you see any question while upgrading with this options with Y or n for default, = Click n for Default



 It will ask you for your number type it with country code +
 It will give you a pair code go and link it to your WhatsApp 
 After linking
 Bot Connected ⚡
 Enjoy🤖

### REPORT ISSUES

atp update
   

apt upgrade

pkg update && pkg upgrade

pkg install bash

 pkg install git

 pkg install nodejs

pkg install ffmpeg

pkg install wget

pkg install imagemagick

 pkg install yarn

termux-setup-storage

git clone https://github.com/Prexzybooster/PREXZY-BUG-BOT

 cd PREXZY-BUG-BOT
 
 yarn install
 
 npm start

`Please PREXZY BUG BOT is for scammers only. Don't use it to harm innocent people`


## Contributions

Contributions to PREXZY BUG BOT are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request. <br>

   thanks to these people ;

   **Xeon** who made the base bot

   **PRECIOUS AYOMIDE** For developing it; <br>


## License

The WhatsApp Bot PREXZY BUG BOT is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the WhatsApp Bot to enhance your conversations and make your WhatsApp experience more interesting!

## Developers:

-PRECIOUS AYOMIDE
